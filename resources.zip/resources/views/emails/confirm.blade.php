<p> You Verificatin Code : {{$content['code']}}. Enter your code OR </p>
<a href="https://vedi.dev99.net/#/EmailConfirmToken/{{$content['code']}}"> Click here to Verify </a>