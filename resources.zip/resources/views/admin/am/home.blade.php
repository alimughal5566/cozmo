@extends( 'admin.layouts.app' )
@section( 'content' )
<h1>Article Management</h1>
@endsection
