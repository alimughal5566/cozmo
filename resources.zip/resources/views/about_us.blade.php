<!DOCTYPE html>
<html>
<head>
	<title>About us</title>
</head>
<body>

  
@extends('layouts.app')
@section('content')

  <section class="about">
  	<div class="container">
  		<div class="banner-sec ">
            <h3>About Us</h3>
          </div>
          <div class="data_about">
					<div>&nbsp;</div>
					<h5>About IPUG.</h5>
					<p>Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.&nbsp;</p>
					<p>Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.&nbsp;</p>
					<p>Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.</p>
					<h5>Why IPUG?</h5>
					<p style="padding-left: 60px;">Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero. &nbsp;</p>
					<p style="padding-left: 60px;">Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero. &nbsp;Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.Lorem ipsum dolor sit amet, consectetur Quisquam doloribus dolorem libero.&nbsp;</p>
				
			</div>
  	</div>
  </section>
    <script src="js/main.js"></script>
@endsection

<!-- </body>
</html> -->