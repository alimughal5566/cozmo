@extends( 'admin.layouts.app' )
@section( 'content' )


<div class="app-title">

  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i>
    </li>
    <li class="breadcrumb-item"><a href="{{url('/admin')}}">Dashboard</a>
    </li>
   
  </ul>
</div>


  
@endsection