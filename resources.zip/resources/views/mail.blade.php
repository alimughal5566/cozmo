<!DOCTYPE html>
<html>
	<head>
		<title>Contact us</title>
	</head>
	<body style="background-color: #F1F3F3;">
		<table style="width: 100%;margin: 0 auto; background-color:border: 1px solid #b7fbf4; #f5fffe;padding: 30px 30px 10px;border-spacing: 0px;    border-collapse: collapse;">
			<tbody>
				<tr>
					<td><p style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;    color: #888888;font-size: 25px;margin: 10px auto;font-weight: 700;text-align: center;">Contact Us</p></td>
				</tr>
				<tr>
					<td>
						<h6 style="    font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif;color: #ee8322;text-align: center;margin:0 15px;font-size: 25px;text-transform: capitalize;">Name : {{$name}}</h6>
						<p style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;width: 80%;margin: 12px auto 15px;text-align: center;color: #555555;font-size: 16px;">{{$msg}}</p>
						<h6 style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #ee8322;    font-size: 16px; text-align: center;margin: 15px;">{{$email}}</h6>
					</td>
				</tr>
				
			</table>
		</body>
	</html>