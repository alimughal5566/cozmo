{{--@extends('layouts.app')--}}

{{--@section('content')--}}
{{--    <h1>asdasdasd</h1>--}}



{{--<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/fonts.css')}}">--}}
{{--<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/renters.css')}}">--}}
{{--<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/blog.css')}}">--}}
{{--<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/blog_header.css')}}">--}}


{{--<div  class="  archive category category-renters-guide category-30 se-global-header float-left">--}}

{{--<div class="navigation collapsed">--}}
{{--    <div class="navigation-mobile-top-banner">--}}
{{--        <div class="navigation-back-to-cozmo">--}}
{{--            <a href="#" class="navigation-back-to-cozmo-link">Search NYC Apartments <i class="fa fa-angle-right" aria-hidden="true"></i></a>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--    <div class="navigation-top-wrapper">--}}
{{--        <div class="container">--}}
{{--            <div class="navigation-top">--}}
{{--                <svg class="open-navigation toggle-navigation" width="20px" height="14px" viewBox="0 0 20 14" version="1.1">--}}

{{--                    <title></title>--}}

{{--                    <defs></defs>--}}
{{--                    <g id="Final_CleanedUp" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">--}}
{{--                        <g id="Assets" transform="translate(-400.000000, -198.000000)" fill="#FFFFFF">--}}
{{--                            <path d="M400,212 L420,212 L420,209.666667 L400,209.666667 L400,212 Z M400,206.166667 L420,206.166667 L420,203.833333 L400,203.833333 L400,206.166667 Z M400,200.333333 L420,200.333333 L420,198 L400,198 L400,200.333333 Z" id="mweb_hamburger"></path>--}}
{{--                        </g>--}}
{{--                    </g>--}}
{{--                </svg>--}}
{{--                <svg class="close-navigation toggle-navigation" width="15px" height="15px">--}}

{{--                    <title></title>--}}
{{--                    <desc>Created with Sketch.</desc>--}}
{{--                    <defs></defs>--}}
{{--                    <g id="Final_CleanedUp" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">--}}
{{--                        <g id="Assets" transform="translate(-348.000000, -197.000000)" fill="#FFFFFF">--}}
{{--                            <polyline id="mweb_close" points="363 198.510714 361.489286 197 355.5 202.989286 349.510714 197 348 198.510714 353.989286 204.5 348 210.489286 349.510714 212 355.5 206.010714 361.489286 212 363 210.489286 357.010714 204.5 363 198.510714"></polyline>--}}
{{--                        </g>--}}
{{--                    </g>--}}
{{--                </svg>--}}
{{--                <div class="navigation-logo-container">--}}
{{--                    <a class="logo" href="#">--}}
{{--                        <img src="{{asset('assets/masterFrontend/img/rent.png')}}">--}}
{{--                    </a>--}}
{{--                    <span class="navigation-by-cozmo">by CoZmo</span>--}}
{{--                </div>--}}
{{--                <div class="navigation-back-to-cozmo">--}}
{{--                    <a href="#" class="navigation-back-to-cozmo-link">Search NYC Apartments <i class="fa fa-angle-right" aria-hidden="true"></i></a>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--    <div class="navigation-bottom-wrapper">--}}
{{--        <div class="container">--}}
{{--            <div class="navigation-bottom">--}}
{{--                <ul class="navigation-links">--}}
{{--                    <li>--}}
{{--                        <a href="#" class="">Trends & Data</a>--}}
{{--                        <ul class="sub-navigation">--}}
{{--                            <li class="sub-navigation-mobile-link"><a href="#" target="" class="">See all Trends & Data</a></li>--}}
{{--                            <li><a href="#" target="" class="">Affordability</a></li>--}}
{{--                            <li><a href="#" target="" class="">Market Reports</a></li>--}}
{{--                            <li><a href="#" target="" class="">Neighborhoods</a></li>--}}
{{--                            <li><a href="#" target="" class="">Rentals</a></li>--}}
{{--                            <li><a href="#" target="" class="">Sales</a></li>--}}
{{--                            <li><a href="#" target="" class="">Data Dashboard</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li>--}}
{{--                        <a href="#" class="">Good Deals</a>--}}
{{--                        <ul class="sub-navigation">--}}
{{--                            <li class="sub-navigation-mobile-link"><a href="#" target="" class="">See all Good Deals</a></li>--}}
{{--                            <li><a href="#" target="" class="">Sales Deals</a></li>--}}
{{--                            <li><a href="#" target="" class="">Rental Deals</a></li>--}}
{{--                            <li><a href="#" target="" class="">Most Popular</a></li>--}}
{{--                            <li><a href="#" target="" class="">Open Houses</a></li>--}}
{{--                            <li><a href="#" target="" class="">Deal of the Week</a></li>--}}
{{--                            <li><a href="#" target="" class="">Housing Lotteries</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li>--}}
{{--                        <a href="#" class="">NYC Living</a>--}}
{{--                        <ul class="sub-navigation">--}}
{{--                            <li class="sub-navigation-mobile-link"><a href="#" target="" class="">See all NYC Living</a></li>--}}
{{--                            <li><a href="#" target="" class="">Design</a></li>--}}
{{--                            <li><a href="#" target="" class="">Celebrity Homes</a></li>--}}
{{--                            <li><a href="#" target="" class="">Exploring NYC</a></li>--}}
{{--                            <li><a href="#" target="" class="">New Developments</a></li>--}}
{{--                            <li><a href="#" target="" class="">#CoZmofinds</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li>--}}
{{--                        <a href="#" class="">Tips & Advice</a>--}}
{{--                        <ul class="sub-navigation">--}}
{{--                            <li class="sub-navigation-mobile-link"><a href="#" target="" class="">See all Tips & Advice</a></li>--}}
{{--                            <li><a href="#" target="" class="">Ask Us</a></li>--}}
{{--                            <li><a href="#" target="" class="">NYC Explained</a></li>--}}
{{--                            <li><a href="#" class="">Discussions</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                    <li>--}}
{{--                        <a href="#" class="">NYC Guides</a>--}}
{{--                        <ul class="sub-navigation">--}}
{{--                            <li class="sub-navigation-mobile-link"><a href="/guides" target="" class="">See all NYC Guides</a></li>--}}
{{--                            <li><a href="#" target="" class="">How to Rent</a></li>--}}
{{--                            <li><a href="#" target="" class="">How to Buy</a></li>--}}
{{--                            <li><a href="#" target="" class="">How to Sell</a></li>--}}
{{--                            <li><a href="#" target="" class="">Neighborhood Guides</a></li>--}}
{{--                            <li><a href="#" target="" class="">Moving to NYC Guide</a></li>--}}
{{--                        </ul>--}}
{{--                    </li>--}}
{{--                </ul>--}}
{{--                <div class="navigation-search-container">--}}
{{--                    <form #>--}}
{{--                        <input type="text" name="s" class="navigation-search" placeholder="Search CoZmo Blog ...">--}}
{{--                        <i class="fa fa-search navigation-search-icon" aria-hidden="true"></i>--}}
{{--                    </form>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--    <div class="navigation-mobile-overlay"></div>--}}
{{--</div>--}}
{{--<div class="container py-5">--}}
{{--    <div class="category-header text-center">--}}
{{--        <h4 class="text-uppercase label-2 category-label">NYC real estate guide</h4>--}}
{{--        <div class="category-icon d-inline-block" style="background-image: url({{asset('assets/masterFrontend/img/rent.png')}})"></div>--}}
{{--        <h1 class="category-title">Renters Guide</h1>--}}
{{--        <div class="category-description text-excerpt-1">--}}
{{--            The ins and outs of renting, from broker’s fees to breaking leases.        </div>--}}
{{--        <a class="category-cta cta cta-dark cta-inline text-uppercase" target="" href="#">How to Get an Apartment in NYC</a>--}}
{{--    </div>--}}
{{--    <!-- Category Children -->--}}
{{--    <ul class="category-children">--}}
{{--        <li class="category-child-card">--}}
{{--            <h2 class="category-child-card__title">The Basics of Renting in NYC</h2>--}}
{{--            <div class="paragraph-2 category-child-card__description">The big question is, what can you afford?</div>--}}
{{--            <ul class="category-child-posts">--}}
{{--                <li><a href="#">Moving to New York?</a></li>--}}
{{--                <li><a href="#">How Much Rent Can I Afford?</a></li>--}}
{{--                <li><a href="#">How to Find a Roommate in NYC</a></li>--}}
{{--            </ul>--}}
{{--        </li>--}}
{{--        <li class="category-child-card">--}}
{{--            <h2 class="category-child-card__title">Should You Use a Rental Broker?</h2>--}}
{{--            <div class="paragraph-2 category-child-card__description">The answer will affect your search process and upfront costs.</div>--}}
{{--            <ul class="category-child-posts">--}}
{{--                <li><a href="#">What Is a No-Fee Listing?</a></li>--}}
{{--                <li><a href="#">Pros and Cons of Using a Broker to Find an Apartment</a></li>--}}
{{--                <li><a href="#">How to Pick a Broker</a></li>--}}
{{--                <li><a href="#">Be Aware of the Bait-and-Switch</a></li>--}}
{{--                <li><a href="#">What is a No-Fee Listing?</a></li>--}}
{{--                <li><a href="#">How to Find a No-Fee Rental in New York City</a></li>--}}
{{--            </ul>--}}
{{--        </li>--}}
{{--        <li class="category-child-card">--}}
{{--            <h2 class="category-child-card__title">Landing That Dream Apartment</h2>--}}
{{--            <div class="paragraph-2 category-child-card__description">From choosing a neighborhood to signing a lease.</div>--}}
{{--            <ul class="category-child-posts">--}}
{{--                <li><a href="#">Signing an Apartment Lease</a></li>--}}
{{--                <li><a href="#">How to Pick a Neighborhood in NYC</a></li>--}}
{{--                <li><a href="#">Finding an Apartment</a></li>--}}
{{--                <li><a href="#">Submitting an Application</a></li>--}}
{{--                <li><a href="#">What is a Guarantor?</a></li>--}}
{{--                <li><a href="#">Signing an Apartment Lease</a></li>--}}
{{--                <li><a href="#">How to Move in NYC Without Losing Your Mind</a></li>--}}
{{--            </ul>--}}
{{--        </li>--}}
{{--        <li class="category-child-card">--}}
{{--            <h2 class="category-child-card__title">The Main Types of NYC Apartments</h2>--}}
{{--            <div class="paragraph-2 category-child-card__description">Because not every bedroom is “legal.”</div>--}}
{{--            <ul class="category-child-posts">--}}
{{--                <li><a href="#">What is a True Two-Bedroom Apartment?</a></li>--}}
{{--                <li><a href="#">What is a Legal Bedroom in NYC?</a></li>--}}
{{--                <li><a href="#">What is a Flex or Convertible Apartment?</a></li>--}}
{{--                <li><a href="#">What is the Difference Between Rent-Controlled and Rent-Stabilized Apartments?</a></li>--}}
{{--            </ul>--}}
{{--        </li>--}}
{{--        <li class="category-child-card">--}}
{{--            <h2 class="category-child-card__title">Now You’re a Renter</h2>--}}
{{--            <div class="paragraph-2 category-child-card__description">Here’s what you need to know.</div>--}}
{{--            <ul class="category-child-posts">--}}
{{--                <li><a href="#">Do You Need Renters Insurance in NYC?</a></li>--}}
{{--                <li><a href="#">NYC Renters: Know Your Rights</a></li>--}}
{{--                <li><a href="#">Can Your Landlord Enter Your Apartment at Any Time?</a></li>--}}
{{--                <li><a href="#">What If You Need to Break Your Lease?</a></li>--}}
{{--                <li><a href="#">How to Get Your Security Deposit Back</a></li>--}}
{{--                <li><a href="#">How to Sublet Your Apartment</a></li>--}}
{{--            </ul>--}}
{{--        </li>--}}
{{--    </ul>--}}

{{--    <!-- Related Categories -->--}}

{{--</div>--}}
{{--</div>--}}

{{--@endsection--}}


@extends('layouts.app')
<div style="height: 15%;"></div>
@include('layouts.top-bar')

<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/style.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('assets/masterFrontend/css/fonts.css')}}">
<link rel="preload" href="fonts/SourceSansPro-Bold-487f2e9da2ff0740755a5ef01dc15a2888b89537795895203a831b13b199d8bb.woff2" as="font" crossorigin="anonymous"/>
<link rel="preload" href="fonts/SourceSansPro-SemiBold-fc772b0188bc262494be9dc529c50893ae189110dfcad5a286512b737aef93b8.woff2" as="font" crossorigin="anonymous"/>
<link rel="preload" href="fonts/SourceSansPro-Regular-ecf76895be1cf9e8b3edb254030e9c9c1d8f3c2efc1f9dc7e04ceff29eccae9c.woff2" as="font" crossorigin="anonymous"/>
<link rel="preload" href="fonts/SourceSansPro-Light-7ec7f22119da3493aedefd66ffd30f0aaf4cf4aee42d8254638bcca5971c3568.woff2" as="font" crossorigin="anonymous"/>
@section('header')
    @include('layouts.header')
@endsection

@section('content')

    {{--<h1>Hello WOrd</h1>--}}

    <div class="Home-featuredContainer grid-container grid-container-9cols-984">


        <!-- Featured Buildings -->

        <ul class="Home-featuredBuildings grid-span-9 grid-container-9cols">
            <li class="Home-featuredBuildingLarge Home-featuredCard Home-featuredCard--large jsFranchiseBoxAd jsGoogleAd">
                <div class="TallCard TallCard--hoverable Home-featuredCardInner">
                    <div id="FranchiseBox_1" style="zoom: 1; opacity: 1;">
                        <img src="{{asset('assets/masterFrontend/img/apartment.png')}}" alt="" style="width: 100%;">
                    </div>
                    <div class="textContent">
                        <ul class="textContentList">
                            <li class="buildingName"><h2>New Developments in Manhattan</h2></li>
                            <li class="propertyCopy"><p>Explore luxury condominiums available now. From elegant boutique residences to full-service buildings in the heart of it all—own something that has never been lived in! </p></li>
                        </ul>
                    </div>
                    <div class="logoContainer"><div class="{{asset('assets/masterFrontend/img/lgo.png')}}"></div></div>
                </div>
            </li>
            <li id="listing_1458011_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1458011"
                data-imp="lt-hfimp-s-1458011"
                data-id="1458011">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Toll Brothers Real Estate Inc.
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            Waterfront
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=2" data-gtm-event-value="869995" href="#">10 Provost Street #2702</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $869,995
                            <span class="TallCard-largeBold--arrow">
            &uarr;
          </span>
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              1 Bed
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              1 Bath
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              704 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>
            <li id="listing_1458011_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1458011"
                data-imp="lt-hfimp-s-1458011"
                data-id="1458011">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Toll Brothers Real Estate Inc.
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            Waterfront
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=2" data-gtm-event-value="869995" href="#">10 Provost Street #2702</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $869,995
                            <span class="TallCard-largeBold--arrow">
            &uarr;
          </span>
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              1 Bed
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              1 Bath
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              704 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>
        </ul>


        <!-- End Featured Buildings -->

        <!-- Featured Listings -->

        <ul class="Home-featuredListings Home-featuredListings--fourAd grid-span-3 grid-span-9-984 grid-container-9cols-984">
            <li id="listing_1401291_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1401291"
                data-imp="lt-hfimp-s-1401291"
                data-id="1401291">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Modern Spaces
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            Flushing
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=1" data-gtm-event-value="684592" href="#">134-37 35th Avenue #8M</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $684,592
                            <span class="TallCard-largeBold--arrow">
            &uarr;
          </span>
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              1 Bed
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              1 Bath
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              569 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>

            <li id="listing_1458011_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1458011"
                data-imp="lt-hfimp-s-1458011"
                data-id="1458011">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Toll Brothers Real Estate Inc.
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            Waterfront
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=2" data-gtm-event-value="869995" href="#">10 Provost Street #2702</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $869,995
                            <span class="TallCard-largeBold--arrow">
            &uarr;
          </span>
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              1 Bed
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              1 Bath
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              704 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>

            <li id="listing_1411272_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1411272"
                data-imp="lt-hfimp-s-1411272"
                data-id="1411272">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Corcoran
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">Gramercy Park</a>
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=3" data-gtm-event-value="1650000" href="#">385 First Avenue #9B</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $1,650,000
                            <span class="TallCard-largeBold--arrow">
            &darr;
          </span>
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              2 Beds
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              2 Baths
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              1,190 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>

            <li id="listing_1462075_featured"
                class="Home-featuredCard grid-span-3-984 item listing featured"
                se:behavior="selectable hoverable clickable"
                data-track="lt-hfclick-s-1462075"
                data-imp="lt-hfimp-s-1462075"
                data-id="1462075">

                <div class="TallCard TallCard--hoverable Home--absolutePosition u-height--full">
                    <div class="TallCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})">

                        <div class="TallCard-listedBy">
                            Listed by Extell Marketing Group
                        </div>

                        <div class="TallCard-imageTag">Featured</div>
                    </div>

                    <div class="TallCard-content">
                        <div class="Title Title--secondarySmCaps u-color-koalaGrey TallCard--marginBottom3">
                            Sale in
                            Hudson Square
                        </div>

                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="featured_listing" data-gtm-event-label="clickslot=4" data-gtm-event-value="5540000" href="#">70 Charlton Street #18E</a>
                        </div>

                        <div class="TallCard-largeBold">
                            $5,540,000
                        </div>

                        <div class="TallCard-bottomStrip u-nowrap">
            <span class="TallCard-info">
              <span class="TallCard-info--bedIcon"></span>
              4 Beds
            </span>
                            <span class="TallCard-info">
              <span class="TallCard-info--bathIcon"></span>
              4.5 Baths
            </span>
                            <span class="TallCard-info Home-featuredSqFt">
              <span class="TallCard-info--sizeIcon"></span>
              2,252 ft&sup2;
            </span>
                        </div>

                    </div>
                </div>
            </li>

        </ul>

        <!-- End Featured Listings -->

        <!-- Apartments for You -->

        <div class="Home-apartmentsForYou grid-span-9">
            <div class="Home-apartmentsForYouInner">
                <h2 class="Title Title--primaryMd Home-sectionTitle">
                    Trending Apartments in NYC
                </h2>
                <div class="Home-apartmentsForYouListContainer">
                    <ul class="Home-apartmentsForYouList flexBox-row flexBox-nowrap jsSlider" data-slider-type="Apartments for You">
                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">Gramercy Park</a>
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="600000" href="#">210 East 15th Street #9D</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $600,000
                                            <span class="LongCard-largeBold--arrow">
              ↓
            </span>
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                1
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                1
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou Home-apartmentForYouAd jsCarouselAd-1 isLoaded"
                            data-ad-slot="Carousel_1">
                            <div class="LongCard LongCard--hoverable Home-apartmentForYouAdInner">
                                <div class="Home-apartmentForYouAdContainer">
                                    <div id="Carousel_1" style="zoom: 1; opacity: 1;">

                                    </div>

                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            Lenox Hill
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="600000" href="#">205 East 63rd Street #15D</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $600,000
                                            <span class="LongCard-largeBold--arrow">
              ↓
            </span>
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                2
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                2
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">West Village</a>
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="899000" href="#">99 Bank Street #2F</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $899,000
                                            <span class="LongCard-largeBold--arrow">
              ↓
            </span>
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                1
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                1
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou Home-apartmentForYouAd jsCarouselAd-2 "
                            data-ad-slot="Carousel_2">
                            <div class="LongCard LongCard--hoverable Home-apartmentForYouAdInner">
                                <div class="Home-apartmentForYouAdContainer">
                                    <div id="Carousel_2" style="zoom: 1; opacity: 1;">

                                    </div>

                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">Upper West Side</a>
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="1495000" href="#">470 West End Avenue #9C</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $1,495,000
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                3
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                2
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">Greenwich Village</a>
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="1775000" href="#">69 W 9th Street #11CDE</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $1,775,000
                                            <span class="LongCard-largeBold--arrow">
              ↓
            </span>
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                2
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                3
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou Home-apartmentForYouAd jsCarouselAd-3 "
                            data-ad-slot="Carousel_3">
                            <div class="LongCard LongCard--hoverable Home-apartmentForYouAdInner">
                                <div class="Home-apartmentForYouAdContainer">
                                    <div id="Carousel_3" style="zoom: 1; opacity: 1;">

                                    </div>

                                </div>
                            </div>
                        </li>

                        <li class="Home-apartmentForYou"
                            se:behavior="selectable hoverable clickable">
                            <div class="LongCard LongCard--hoverable">
                                <div class="LongCard-inner">
                                    <div class="LongCard-image" style="background-image: url({{asset('assets/masterFrontend/img/apartment.png')}})"></div>
                                    <div class="LongCard-content">
                                        <div class="Title Title--secondarySmCaps u-color-koalaGrey">
                                            <a class="u-color-koalaGrey--important u-text--noDecoration" href="#">Soho</a>
                                        </div>

                                        <div class="u-ellipsis u-color-brightBlue" data-listing-type="Sale">
                                            <a se:clickable:target="true" class="Title Title--secondary u-color-classicBlue--important u-text--noDecoration" data-gtm-event-category="sales_homepage" data-gtm-event-action="recommended" data-gtm-event-label="listing_click" data-gtm-event-value="2500000" href="#">35 Wooster Street #4R</a>
                                        </div>

                                        <div class="LongCard-largeBold">
                                            $2,500,000
                                            <span class="LongCard-largeBold--arrow">
              ↓
            </span>
                                        </div>

                                        <div class="LongCard-bottomStrip u-nowrap">
              <span class="LongCard-info">
                <span class="LongCard-info--bedIcon"></span>
                3
              </span>
                                            <span class="LongCard-info">
                <span class="LongCard-info--bathIcon"></span>
                2
              </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>

                    </ul>
                    <a class="Home-apartmentsForYouListArrow Home-apartmentsForYouListArrow--prev jsSliderPrev"
                       href="javascript:void(0)"
                       data-event-category="sales_homepage"
                       data-event-action="recommended"
                       data-event-label="left_arrow_click"
                       data-event-value="">
                        <div class="CircleArrow CircleArrow--prev">Prev</div>
                    </a>
                    <a class="Home-apartmentsForYouListArrow jsSliderNext"
                       href="javascript:void(0)"
                       data-event-category="sales_homepage"
                       data-event-action="recommended"
                       data-event-label="right_arrow_click"
                       data-event-value="">
                        <div class="CircleArrow">Next</div>
                    </a>
                </div>

            </div>
        </div>

        <!-- End Apartments for You -->

        <div class="Home-featuredExtras grid-span-9">




            <!-- Blog -->

            <div class="Home-topDivider Home--vertPadding24">
                <h2 class="Title Title--primaryMd Home-sectionTitle">One Block Over</h2>

                <div class="Home-blog">
                    <ul class="Home-blogFeed latest">
                        <li class="Home-blogPost">
                            <a class="Home-blogPostImage"
                               href="#"

                               style="background-image:url({{asset('assets/masterFrontend/img/apartment.png')}})">
                            </a>
                            <div>
                                <h3 class="Home-blogFeedTitle Title Title--secondarySmCaps u-color-koalaGrey u-noMargin">The Latest</h3>
                                <div class="Home-blogPostLink">
                                    <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">5 Virtual Home Tours to Take From Your Sofa</a>
                                </div>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">Here&#39;s What $1.5M Gets You in NYC Right Now</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">NYC Apartments for $2400: What You Can Rent Right Now</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">A Stylish Kips Bay Duplex for $465K</a>
                            </div>
                        </li>
                    </ul>
                    <ul class="Home-blogFeed popular">
                        <li class="Home-blogPost">
                            <a class="Home-blogPostImage"
                               href="#"

                               style="background-image:url({{asset('assets/masterFrontend/img/apartment.png')}})">
                            </a>
                            <div>
                                <h3 class="Home-blogFeedTitle Title Title--secondarySmCaps u-color-koalaGrey u-noMargin">Most Popular</h3>
                                <div class="Home-blogPostLink">
                                    <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">Finished Netflix? 15 Ideas for What New Yorkers Should Watch Next!</a>
                                </div>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">A Quintessential Prewar UWS 1BR Asks $2,650</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">Your Guide to NYC Laundry Services (Plus COVID Tips!)</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">Spa Bathrooms: Manhattan&#39;s 10 Most Luxe </a>
                            </div>
                        </li>
                    </ul>
                    <ul class="Home-blogFeed trends">
                        <li class="Home-blogPost">
                            <a class="Home-blogPostImage"
                               href="#"

                               style="background-image:url({{asset('assets/masterFrontend/img/apartment.png')}})">
                            </a>
                            <div>
                                <h3 class="Home-blogFeedTitle Title Title--secondarySmCaps u-color-koalaGrey u-noMargin">Trends &amp; Data</h3>
                                <div class="Home-blogPostLink">
                                    <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">Sales and Inventory Fall as COVID-19 Disrupts Shopping Season</a>
                                </div>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">How Will COVID-19 Impact NYC Home Prices?</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">What Happens to NYC Rents During a Recession?</a>
                            </div>
                        </li>
                        <li class="Home-blogPost">
                            <div class="Home-blogPostLink">
                                <a class="u-color-whaleGrey--important" rel="noopener noreferrer" href="#">COVID-19 Cuts New Inventory, But Prices Stay Flat</a>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>

            <!-- End Blog -->

        </div>

    </div>

@endsection
