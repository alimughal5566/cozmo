<style type="text/css">
	li > a{
		color: grey;
	}
</style>
	<div>
		@section('footer')
		<footer class="footer-bg">
	        <div class="social-icons">
	          <h3>Follow Us On</h3>
	          <ul class="social-ul">
	            <li><a href="#"><img src="images/twitter.png"></a> </li>
	            <li><a href="#"><img src="images/instagram.png"></a> </li>
	            <li><a href="#"><img src="images/pintrest.png"></a> </li>
	            <li><a href="#"><img src="images/facebook.png"> </a></li>
	            <li><a href="#"><img src="images/g+.png"></a> </li>
	          </ul>
	        </div>
	        <div class="contentss">
	          <div class="container">
	            <div class="row">
	              <div class="col-md-4">
	                <h3>LINKS</h3>
	                <ul class="p-0 footer-ul" style="list-style: none;">
	                  <li><i class="fa fa-caret-right"></i> <a href="">Benefits of Membership</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="/about_us">About IPUG</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Meet the Exec</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Become a Member</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Become a Member</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Create a website login</a></li>
	                </ul>
	              </div>
	              <div class="col-md-4">
	                <h3>Our Department</h3>
	                <ul class="p-0 footer-ul" style="list-style: none;">
	                  <li><i class="fa fa-caret-right"></i> <a href="/events">Events</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">IPUG Charity</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Our Services</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="">Recent Post</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="/articles">News & Articles</a></li>
	                  <li><i class="fa fa-caret-right"></i> <a href="/contact_us">Contact Us</a></li>
	                </ul>
	              </div>
	              <div class="col-md-4">
	                <h3>Our Department</h3>
	                <ul class="p-0 footer-ul" style="list-style: none;">
	                  <li>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</li>
	                  <li class="mt-4"><div class="loc loc2">
	                    <img class="mr-2" src="images/helpline.png">
	                    <p class=""> Helpline
	                      <br>
	                    +92-4522156-45</p>
	                    
	                  </div></li>
	                  <li><div class="loc loc2">
	                    <img src="images/location.png">
	                    <p class="location-p"> 322 Villing Aven<br>
	                    London sub 330</p>
	                  </div></li>
	                  
	                  
	                </ul>
	              </div>
	            </div>
	          </div>
	        </div>
	        <div class="terms-sec">
	          <p>Copyright © 1999-2014, IPUG.  All rights reserved.  |  Hosted & Powered by<a class="step" href="#"> StepInnSolution</a></p>
	        </div>
	    </footer>
		@show
	</div>