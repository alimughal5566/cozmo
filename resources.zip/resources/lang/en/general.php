<?php

return [

    /*
    |--------------------------------------------------------------------------
    | General Lines
    |--------------------------------------------------------------------------
    |
    
    */

    'site_title'         => 'VEDI - Voyages Experiences Destinations International',
    'vedi_dashboard'             => 'VEDI Dashboard',
    'home'               => 'Home',
    'collapse_title'     => 'Vedi',
    'logout'             => 'Logout',
    'search'             => 'What are you looking for...',
    'cancel'             => 'Cancel',
    'save'               => 'Save',
    'success_message'    => 'Saved Successfully!',
    'actions'    => 'Actions',
    'created_at'    => 'Created At',
    'sr'    => 'Sr#',

];
