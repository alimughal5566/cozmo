<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Sidebar Lines
    |--------------------------------------------------------------------------
    |
    
    */

    'dashboard'            => 'Dashboard',
    'total_users'           => 'Total Users',
    'total_trips'        => 'Total Trips',

];
