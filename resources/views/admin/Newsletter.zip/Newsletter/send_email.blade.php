@extends( 'admin.layouts.app' )
@section( 'content' )
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/css/select2.min.css" rel="stylesheet" />

<style>
.selectpicker {
	width:100%;
}
iframe {
	width:80%;
	border:thin solid black;
	height:250px;
}
.row {
	margin-bottom:10px;
}

#email-template-html {
	border:2px solid #ced4da;
	border-radius: 5px;
	max-height:500px;
	min-height:500px;
	overflow-y:auto;
}

</style>
<div class="app-title">

  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i>
    </li>
    <li class="breadcrumb-item"><a href="{{url('/admin')}}">Dashboard</a>
    </li>
   
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="tile">
      <h3 class="tile-title">News Letters
      </h3>
      <div class="table-responsive">
     
		 <form method="POST" action="{{url('/sendmail')}}">
			 @csrf
			<input type="hidden" name="email_id_list" value="" />
		 </form>
		 <div class="row">
		 	 <div class="col col-md-7">

				 <label>Select Emails</select>
			 </div>
			 <div class="col col-md-7">
					 <select name="email-list" id="email-list" class="selectpicker" multiple>
					 <?php foreach ($selected_subs_list as $key => $email): ?>
						<option value="<?php echo $email['id']; ?>" selected><?php echo $email['email']; ?></option>
					 <?php endforeach; ?>
					 </select>
			 </div>
		 </div>
		 <div class="row">
			 <div class="col col-md-7">
				<label>Select Template</label>
				<select id="template" class="form form-control">
					<option value="">Select Template</option>				
				 <?php foreach ($email_templates as $key => $template): ?>								
					<option value="<?php echo $template->id; ?>"><?php echo $template->name; ?></option>
				 <?php endforeach; ?>
				</select>
			 </div>
		 </div>		 
		 <div class="row">
			 <div class="col col-md-7">
				<label>Select Competition</label>
				<select id="product" class="form form-control">
					<option value="">Select Competition</option>								
				 <?php foreach ($products as $key => $product): ?>								
					<option value="<?php echo $product->id; ?>"><?php echo $product->name; ?></option>
				 <?php endforeach; ?>
				</select>
			 </div>
		 </div>
		 <div class="row">
		 
			 <div class="col col-md-12">
				<div id="email-template-html"></div>
				<!--<iframe src='about:blank'></iframe>-->
			 </div>
		 </div>	


		 <div class="row"> 
			<div class="col col-md-12" id="show_button">
				<button class="btn btn-primary" id="send-email">Send</button>
		 	</div>
		 </div>
		
    </div>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.8/js/select2.min.js"></script>
<script src="<?php echo url('/js/waitingfor.js'); ?>"></script>


<script>
	$(document).ready(function(){
	
		$('#email-list').select2();
				
		var template_id;
		var product_id;
		
		$('#template, #product').change(function(){
			template_id           = $('#template').val();
			product_id            = $('#product').val();
			
			if (template_id != '' && product_id != '') {
				var template_action   = 'emailtemplate/'+template_id+'/'+product_id;
				var show_template_url = '{{url("/")}}/'+template_action;	
				var url = 'show_html/'+template_id+'/'+product_id;
				var my_tem = '{{url("/")}}/'+url;
				$("#email-template-html").load(show_template_url);
				$('#show_button').append('<a class="btn btn-primary" href="'+my_tem+'"  >Show html</a>');

			}

		});
		
		$('#email-list').change(function(){
			console.log($('#email-list').val());
		});
		
		$('#send-email').click(function(){
			
			template_id = $('#template').val();
			product_id  = $('#product').val();
			email_ids   = $('#email-list').val();		
					
			if (template_id != '' && product_id != '' && email_ids.length > 0) {
				var post_data 		     = {};
				post_data['_token']      = '{{csrf_token()}}';
				post_data['template_id'] = template_id;
				post_data['product_id']  = product_id;
				post_data['email_ids']   = email_ids;
				
				waitingDialog.show('Sending Email');							
					
				$.ajax({
					url:    '{{route("send_subscription_mail")}}',
					method: 'POST',
					data:    post_data,
					success: function(response) {
						if (response.status == 'success') {
							swal("Email Sent", "Subscription email sent to users", "success");	
						}
						waitingDialog.hide();			
					}
				});				
			}
			else {
				if (template_id == '') {
					swal("No Template Selected", "Choose one of the templates from the list", "error");	
				}
				else if (product_id == '') {
					swal("No Competition Selected", "Choose one of the competitions from the list", "error");	
					
				}
				else if (email_ids.length == 0) {
					swal("No Subscriber selected", "Please select at least one email", "error");	
					
				}
				
			}

		});
		
	});
</script>
@endsection