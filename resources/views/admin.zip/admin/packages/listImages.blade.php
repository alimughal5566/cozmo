@extends( 'admin.layouts.app' )
@section( 'content' )
	<section class="cust_back_color">
		<div class="container">
			<div class="img_dlt">
				<a class="btn btn-primary" href="#">delete all</a>
				<a class="btn btn-primary" href="#">Upload images</a>				
			</div>
			<div class="view_img">
				<ul>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="img_sec">
								<div class="img">
									<img class="img-fluid" src="https://via.placeholder.com/150">
								</div>
								<div class="view_img_btn">
									<button class="btn btn-primary" type="button">View</button>
									<button class="btn btn-primary" type="button">Delete</button>
								</div>
							</div>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</section>
	@endsection
