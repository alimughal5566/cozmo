   @extends('layouts.app')
   @section('content')
   <h3 class="text-center hows_work " style="margin: 30px 0;">Live Competition</h3>

   	<h1 class="text-center">Under Development</h1>

   @endsection