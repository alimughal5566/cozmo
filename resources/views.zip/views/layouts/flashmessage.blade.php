<div id="covid-banner" class="Flash flash_notice flexBox-row flexBox-alignMiddle">
    <div class="Container Flash-wrapper">
        <div class="Flash-content">
            Explore CoZmo-web’s
            <a rel="noopener noreferrer" href="#"> guides, resources, and stories</a> about NYC real estate and COVID-19.
        </div>
    </div>
</div>
<div id='header_print_info' class='only-print'>
    Printed from CoZmo-web.com at 03:21 AM, Apr 27 2020
</div>
