@extends('layouts.app')
@section('content')
<style>
    .com-titile{
        color:#ee8322;
            font-size: 20px;
    }
</style>

<div class="blog">
     <div class="container" style="min-height:550px;">
  <h1 class="text-center">Share and earn free credits</h1>
  
 
    <div class="feref">
        <p class="m-0 com-titile"><b>Commission :</b></p>
        <p class="m-0">Once you have created an account you will be able to share our competitions with your friends and family. When your friends/family create an account this will be linked to your account. Meaning you will earn 5% free credit from all their purchases, this credit can be used to play our games for free.. Giving you the chance of winning one of our top prizes.</p>
        <p class="m-0 com-titile"><b>Free Tickets</b></p>
        <p class="m-0">If you reshare our competitions we will give you a free ticket to our free ticket draw. Meaning that you have the chance of winning a free ticket to shared competition.</p>
        <p class="m-0"><small>Watch our Live draw to see if you have won!</small></p>
    </div>
  </div>
</div>


@endsection