@extends('layouts.app')
@section('content')

<div class="container" style="margin-top:15px;">
<div class="alert alert-danger">No Record Found</div>
</div>


@endsection