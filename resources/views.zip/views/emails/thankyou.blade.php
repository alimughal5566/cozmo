<div class="content">
	<p>Hello {{ $content['name'] }},</p>
	<p>Thank you for register with us. Please login to make  travel plan with friends</p>
</div>
<a href="https://vedi.dev99.net/" > Login Now </a>