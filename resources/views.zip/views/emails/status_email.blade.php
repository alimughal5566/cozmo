<div class="content">
    <p> {{ $user_email }}</p>
    <p> {{ $competition }}</p>
    <p> {{ $ticket_number }}</p>
    <p> {{ $msg }}</p>
</div>