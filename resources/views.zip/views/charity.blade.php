<!DOCTYPE html>
<html>
<head>
	<title>Charity</title>
</head>
<body>
  
@extends('layouts.app')
@section('content')
  <section class="all_cheriti">
    <div class="container">
      <div class="banner-sec ">
            <h3>All Cherities</h3>
            <p>Index and Benchmarking SIG  <small class="red-small">5 May 2020 at 15:30</small><br>
            Columbia Threadneedle Investments <br> Columbia Threadneedle Investments - 78 Cannon Street - London EC4N 6AG - United Kingdom</p>
          </div>
          <div class="search-sec">
              <div class="container p-0">
                <div class="row">
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/1.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/2.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/3.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  
                  
                </div>
              </div>
            </div>
            <div class="search-sec">
              <div class="container p-0">
                <div class="row">
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/1.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/2.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="card-content">
                      <div class="card-img">
                        <img src="images/3.jpg" alt="">
                        
                      </div>
                      <div class="card-desc">
                        <h4>London Children’s</h4>
                        <p>Lunch Party at FoodVillas</p>
                        <p>Etiam dignissim sit amet felis</p>
                        <p>Assistants</p>
                        <div class="btnee"><a href="#" class="btn-card">Read All</a>   </div>
                      </div>
                    </div>
                  </div>
                  
                  
                </div>
              </div>
            </div>
    </div>
  </section>
    <script src="js/main.js"></script>
@endsection()

</body>
</html>